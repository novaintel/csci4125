Visual Studio 2013 Ultimate Project
Developed on Windows 8.1 Pro
Program does not acept input file
No Commandline arguments are implemented with this program
Assignment 1 Times contain graphs for Question 1